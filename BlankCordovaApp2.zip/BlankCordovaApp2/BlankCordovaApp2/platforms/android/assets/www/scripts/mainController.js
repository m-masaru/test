{
  'use strict';
  var module = ons.bootstrap("ONSEN_03_APP", ['onsen']);
 
  module.controller("MainPageController", function ($scope) {
 
    $scope.searchkey = "";
 
    // �Z���������s��
    $scope.searchSuggestion = function(){
      if(!!$scope.searchkey){
        myNav.pushPage("result.html", { keyword: $scope.searchkey });
      }
      else{
        alert("�����L�[����͂��Ă�������...");
      }
    }
 
  });
 
  module.controller("resultPageController", function ($scope, $http, GetAmazonSuggestionsService){
    $scope.keywords = [];
 
    var nav_options = myNav.getCurrentPage().options;
 
    GetAmazonSuggestionsService.getsuggestions(nav_options.keyword, function(res){
      $scope.keywords = res.results;
    });
 
    $scope.recursiveSearch = function(index){
      myNav.pushPage("result.html", {
        keyword: $scope.keywords[index].keyword
      });
    };
 
    $scope.move2top = function(){
      myNav.resetToPage("main.html");
    }
  });
 
  module.service("GetAmazonSuggestionsService", function ($http){
    this.getsuggestions = function(searchkey, callback){
      var params = {
        q: searchkey,
        method: "completion",
        mkt: 6,
        "search-alias": "aps",
        callback: "JSON_CALLBACK"
      };
 
      // angular��http�T�[�r�X��jsonp
      $http.jsonp(
        "http://completion.amazon.co.jp/search/complete",
        {
          params: params
        }
      ).success(function(data){
        console.log(data);
 
        var search_title = data[0];
        var search_result_arr = (function(items){
 
          var res = [];
 
          if(!items){ return res; }
 
          for(var i = 0; i < items.length; i++){ res.push({keyword: items[i]}); }
 
          return res;
        })(data[1]);
 
        callback({
          searchkey: search_title,
          results: search_result_arr
        });
 
      }).error(function(){
        alert("�G���[���������܂���");
      });
    }
  });
}