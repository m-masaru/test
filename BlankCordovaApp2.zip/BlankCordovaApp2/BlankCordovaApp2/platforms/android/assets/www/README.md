# OnsenUI-YouTube

This is an example application of [Onsen UI](http://onsen.io) using [YouTube API](https://developers.google.com/youtube/v3/).
The app is based on this [JukeTube project](http://jgthms.com/juketube/).

Try it here: http://frandiox.github.io/OnsenUI-YouTube
